import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PDFTool } from '../constants/tools';
import { ToolCard } from './ToolCard';

export const ToolGrid = () => {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q')?.toLowerCase() || '';
  const [tools, setTools] = useState<PDFTool[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const categories = ['Popular', 'Convert to PDF', 'Convert from PDF', 'Edit', 'Security', 'Organize'] as const;

  useEffect(() => {
    fetch('/api/tools')
      .then(res => res.json())
      .then(data => {
        setTools(data);
        setIsLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch tools', err);
        setIsLoading(false);
      });
  }, []);

  const filteredTools = tools.filter(tool => 
    tool.name.toLowerCase().includes(searchQuery) || 
    tool.description.toLowerCase().includes(searchQuery) ||
    tool.category.toLowerCase().includes(searchQuery)
  );

  if (isLoading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
      </div>
    );
  }

  if (searchQuery && filteredTools.length === 0) {
    return (
      <div className="py-20 text-center">
        <p className="text-lg text-slate-500">No tools found matching "{searchQuery}"</p>
        <button 
          onClick={() => window.history.pushState({}, '', '/')}
          className="mt-4 text-indigo-600 font-semibold hover:underline"
        >
          Clear search
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-16 py-12">
      {categories.map((category) => {
        const tools = filteredTools.filter(t => t.category === category);
        if (tools.length === 0) return null;

        return (
          <section key={category} id={category.toLowerCase().replace(/\s+/g, '-')}>
            <div className="mb-8 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                {category}
              </h2>
              <div className="h-px flex-1 bg-slate-100 mx-8 hidden sm:block"></div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {tools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
};
