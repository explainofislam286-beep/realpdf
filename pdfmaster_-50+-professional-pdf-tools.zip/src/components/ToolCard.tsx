import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { PDFTool } from '../constants/tools';
import { cn } from '../lib/utils';
import { getToolIcon } from '../lib/icons';

interface ToolCardProps {
  tool: PDFTool;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  const Icon = getToolIcon(tool.id);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3 }}
    >
      <Link 
        to={`/tool/${tool.id}`}
        className="group relative block h-full rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-500/10"
      >
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-50 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
          <Icon size={24} />
        </div>
        <h3 className="mb-2 text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
          {tool.name}
        </h3>
        <p className="text-sm text-slate-500 leading-relaxed">
          {tool.description}
        </p>
        
        <div className="mt-4 flex items-center text-xs font-semibold uppercase tracking-wider text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
          Use Tool →
        </div>
      </Link>
    </motion.div>
  );
};
