import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { FileText, Search, Menu, X } from 'lucide-react';
import { cn } from '../lib/utils';

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const searchQuery = searchParams.get('q') || '';

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const currentPath = window.location.pathname;
    
    if (currentPath !== '/') {
      navigate(`/?q=${encodeURIComponent(value)}`);
    } else {
      if (value) {
        setSearchParams({ q: value });
      } else {
        setSearchParams({});
      }
    }
  };

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-black/5 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2" onClick={closeMenu}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-indigo-200 shadow-lg">
              <FileText size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">PDFMaster</span>
          </Link>
        </div>

        <nav className="hidden md:flex md:items-center md:gap-8">
          <Link to="/" className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">All Tools</Link>
          <Link to="/#popular" className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">Popular</Link>
          <Link to="/#convert-to-pdf" className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">Convert</Link>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Search tools..." 
              value={searchQuery}
              onChange={handleSearch}
              className="h-10 w-64 rounded-full border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
            />
          </div>
        </nav>

        <div className="md:hidden">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white p-4 space-y-4">
          <Link to="/" className="block text-base font-medium text-slate-600" onClick={closeMenu}>All Tools</Link>
          <Link to="/#popular" className="block text-base font-medium text-slate-600" onClick={closeMenu}>Popular</Link>
          <Link to="/#convert-to-pdf" className="block text-base font-medium text-slate-600" onClick={closeMenu}>Convert</Link>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Search tools..." 
              value={searchQuery}
              onChange={handleSearch}
              className="h-10 w-full rounded-full border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm"
            />
          </div>
        </div>
      )}
    </header>
  );
};
