import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Github, Twitter, Mail } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="border-t border-slate-100 bg-slate-50 pt-16 pb-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-4">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white">
                <FileText size={18} />
              </div>
              <span className="text-lg font-bold tracking-tight text-slate-900">PDFMaster</span>
            </Link>
            <p className="text-sm text-slate-500 leading-relaxed">
              The ultimate suite of PDF tools for professionals. Fast, secure, and free online PDF processing.
            </p>
            <div className="mt-6 flex gap-4">
              <a href="#" className="text-slate-400 hover:text-indigo-600 transition-colors"><Twitter size={20} /></a>
              <a href="#" className="text-slate-400 hover:text-indigo-600 transition-colors"><Github size={20} /></a>
              <a href="#" className="text-slate-400 hover:text-indigo-600 transition-colors"><Mail size={20} /></a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4">Solutions</h3>
            <ul className="space-y-2">
              <li><Link to="/merge-pdf" className="text-sm text-slate-500 hover:text-indigo-600">Merge PDF</Link></li>
              <li><Link to="/split-pdf" className="text-sm text-slate-500 hover:text-indigo-600">Split PDF</Link></li>
              <li><Link to="/compress-pdf" className="text-sm text-slate-500 hover:text-indigo-600">Compress PDF</Link></li>
              <li><Link to="/pdf-to-word" className="text-sm text-slate-500 hover:text-indigo-600">PDF to Word</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-slate-500 hover:text-indigo-600">About Us</a></li>
              <li><a href="#" className="text-sm text-slate-500 hover:text-indigo-600">Privacy Policy</a></li>
              <li><a href="#" className="text-sm text-slate-500 hover:text-indigo-600">Terms of Service</a></li>
              <li><a href="#" className="text-sm text-slate-500 hover:text-indigo-600">Contact</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4">Newsletter</h3>
            <p className="text-sm text-slate-500 mb-4">Get the latest updates and PDF tips.</p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm focus:border-indigo-500 focus:outline-none"
              />
              <button className="h-10 rounded-lg bg-indigo-600 px-4 text-sm font-medium text-white hover:bg-indigo-700 transition-colors">
                Join
              </button>
            </form>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-400">
            © {new Date().getFullYear()} PDFMaster. All rights reserved.
          </p>
          <div className="flex gap-8">
            <span className="text-xs text-slate-400">Made with ❤️ for productivity</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
