import { 
  FileText, 
  Merge, 
  Scissors, 
  Zap, 
  FileImage, 
  FileCode, 
  Lock, 
  Unlock, 
  RotateCw, 
  Type, 
  Hash, 
  Trash2, 
  ArrowDownUp, 
  Image as ImageIcon, 
  FileJson, 
  FileSpreadsheet, 
  Presentation, 
  Globe, 
  ShieldCheck, 
  PenTool, 
  Search, 
  Layers, 
  Maximize, 
  Minimize, 
  FileSignature, 
  FileCheck, 
  FileSearch, 
  Layout, 
  Settings, 
  Download, 
  Eye, 
  FileEdit, 
  FileMinus, 
  FilePlus, 
  RefreshCw, 
  ExternalLink, 
  BookOpen, 
  FileArchive, 
  Table, 
  FileWarning
} from 'lucide-react';

export interface PDFTool {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: 'Popular' | 'Convert to PDF' | 'Convert from PDF' | 'Edit' | 'Security' | 'Organize';
  seoTitle: string;
  seoDescription: string;
  longDescription?: string;
  features?: string[];
  useCases?: string[];
  steps?: string[];
}

export const PDF_TOOLS: PDFTool[] = [
  // Popular
  {
    id: 'merge-pdf',
    name: 'Merge PDF',
    description: 'Combine multiple PDFs into one single document easily.',
    icon: Merge,
    category: 'Popular',
    seoTitle: 'Merge PDF Online - Combine PDF Files for Free',
    seoDescription: 'The easiest way to combine multiple PDF files into one. No registration required. Fast, secure, and free online PDF merger.'
  },
  {
    id: 'split-pdf',
    name: 'Split PDF',
    description: 'Extract pages from your PDF or save each page as a separate PDF.',
    icon: Scissors,
    category: 'Popular',
    seoTitle: 'Split PDF Online - Extract Pages from PDF',
    seoDescription: 'Split a PDF file into multiple documents or extract specific pages. High-quality PDF splitting tool.'
  },
  {
    id: 'compress-pdf',
    name: 'Compress PDF',
    description: 'Reduce the file size of your PDF while maintaining quality.',
    icon: Zap,
    category: 'Popular',
    seoTitle: 'Compress PDF Online - Reduce PDF File Size',
    seoDescription: 'Reduce the size of your PDF documents without losing quality. Optimize PDFs for web and email sharing.'
  },
  {
    id: 'pdf-to-word',
    name: 'PDF to Word',
    description: 'Convert PDF documents to editable Word files.',
    icon: FileText,
    category: 'Popular',
    seoTitle: 'Convert PDF to Word Online - Free PDF to DOCX',
    seoDescription: 'Convert PDF to Word (DOCX) accurately. Keep the original layout and formatting of your document.'
  },

  // Convert to PDF
  {
    id: 'word-to-pdf',
    name: 'Word to PDF',
    description: 'Convert Microsoft Word documents to PDF.',
    icon: FileText,
    category: 'Convert to PDF',
    seoTitle: 'Convert Word to PDF Online - DOCX to PDF',
    seoDescription: 'Make DOC and DOCX files easy to read by converting them to PDF. High-quality Word to PDF conversion.'
  },
  {
    id: 'excel-to-pdf',
    name: 'Excel to PDF',
    description: 'Convert Excel spreadsheets to PDF.',
    icon: FileSpreadsheet,
    category: 'Convert to PDF',
    seoTitle: 'Convert Excel to PDF Online - XLSX to PDF',
    seoDescription: 'Convert Excel tables to PDF documents with ease. Perfect for sharing reports and data.'
  },
  {
    id: 'ppt-to-pdf',
    name: 'PPT to PDF',
    description: 'Convert PowerPoint presentations to PDF.',
    icon: Presentation,
    category: 'Convert to PDF',
    seoTitle: 'Convert PPT to PDF Online - PowerPoint to PDF',
    seoDescription: 'Convert your PowerPoint slides into a PDF document for easy viewing and sharing.'
  },
  {
    id: 'jpg-to-pdf',
    name: 'JPG to PDF',
    description: 'Convert JPG images to PDF documents.',
    icon: FileImage,
    category: 'Convert to PDF',
    seoTitle: 'Convert JPG to PDF Online - Images to PDF',
    seoDescription: 'Convert JPG, PNG, and other images to PDF. Adjust orientation and margins easily.'
  },
  {
    id: 'html-to-pdf',
    name: 'HTML to PDF',
    description: 'Convert web pages to PDF documents.',
    icon: Globe,
    category: 'Convert to PDF',
    seoTitle: 'Convert HTML to PDF Online - Web to PDF',
    seoDescription: 'Save any web page as a PDF document. Just enter the URL and convert instantly.'
  },

  // Convert from PDF
  {
    id: 'pdf-to-excel',
    name: 'PDF to Excel',
    description: 'Extract data from PDF to Excel spreadsheets.',
    icon: FileSpreadsheet,
    category: 'Convert from PDF',
    seoTitle: 'Convert PDF to Excel Online - PDF to XLSX',
    seoDescription: 'Extract tables from PDF files to Microsoft Excel spreadsheets accurately.'
  },
  {
    id: 'pdf-to-ppt',
    name: 'PDF to PPT',
    description: 'Convert PDF documents to PowerPoint slides.',
    icon: Presentation,
    category: 'Convert from PDF',
    seoTitle: 'Convert PDF to PPT Online - PDF to PowerPoint',
    seoDescription: 'Turn your PDF documents into editable PowerPoint presentations.'
  },
  {
    id: 'pdf-to-jpg',
    name: 'PDF to JPG',
    description: 'Extract images from PDF or convert pages to JPG.',
    icon: ImageIcon,
    category: 'Convert from PDF',
    seoTitle: 'Convert PDF to JPG Online - PDF to Image',
    seoDescription: 'Extract all images from a PDF or convert each page into a high-quality JPG image.'
  },
  {
    id: 'pdf-to-png',
    name: 'PDF to PNG',
    description: 'Convert PDF pages to PNG images.',
    icon: ImageIcon,
    category: 'Convert from PDF',
    seoTitle: 'Convert PDF to PNG Online - PDF to PNG',
    seoDescription: 'Convert PDF pages to high-quality PNG images with transparent backgrounds.'
  },
  {
    id: 'pdf-to-text',
    name: 'PDF to Text',
    description: 'Extract plain text from your PDF documents.',
    icon: Type,
    category: 'Convert from PDF',
    seoTitle: 'Convert PDF to Text Online - Extract Text from PDF',
    seoDescription: 'Extract all text from your PDF files and save it as a plain text (.txt) file.'
  },

  // Edit
  {
    id: 'edit-pdf',
    name: 'Edit PDF',
    description: 'Add text, shapes, and images to your PDF.',
    icon: PenTool,
    category: 'Edit',
    seoTitle: 'Edit PDF Online - Free PDF Editor',
    seoDescription: 'Add text, images, and annotations to your PDF documents for free.'
  },
  {
    id: 'rotate-pdf',
    name: 'Rotate PDF',
    description: 'Rotate your PDF pages permanently.',
    icon: RotateCw,
    category: 'Edit',
    seoTitle: 'Rotate PDF Online - Rotate PDF Pages',
    seoDescription: 'Rotate individual pages or the entire PDF document. Save the rotation permanently.'
  },
  {
    id: 'add-page-numbers',
    name: 'Add Page Numbers',
    description: 'Add page numbers to your PDF document.',
    icon: Hash,
    category: 'Edit',
    seoTitle: 'Add Page Numbers to PDF Online',
    seoDescription: 'Easily add page numbers to your PDF. Choose position, font, and size.'
  },
  {
    id: 'add-watermark',
    name: 'Add Watermark',
    description: 'Add text or image watermark to your PDF.',
    icon: ShieldCheck,
    category: 'Edit',
    seoTitle: 'Add Watermark to PDF Online',
    seoDescription: 'Protect your documents by adding a text or image watermark to all pages.'
  },

  // Security
  {
    id: 'unlock-pdf',
    name: 'Unlock PDF',
    description: 'Remove password and restrictions from PDF.',
    icon: Unlock,
    category: 'Security',
    seoTitle: 'Unlock PDF Online - Remove PDF Password',
    seoDescription: 'Remove passwords and security restrictions from your PDF files instantly.'
  },
  {
    id: 'protect-pdf',
    name: 'Protect PDF',
    description: 'Add password and encrypt your PDF.',
    icon: Lock,
    category: 'Security',
    seoTitle: 'Protect PDF Online - Add Password to PDF',
    seoDescription: 'Secure your PDF documents with a password and strong encryption.'
  },
  {
    id: 'sign-pdf',
    name: 'Sign PDF',
    description: 'Sign your PDF with a digital signature.',
    icon: FileSignature,
    category: 'Security',
    seoTitle: 'Sign PDF Online - Digital Signature for PDF',
    seoDescription: 'Sign your PDF documents with an electronic signature. Fast and secure.'
  },

  // Organize
  {
    id: 'remove-pages',
    name: 'Remove Pages',
    description: 'Delete unwanted pages from your PDF.',
    icon: Trash2,
    category: 'Organize',
    seoTitle: 'Remove PDF Pages Online - Delete Pages from PDF',
    seoDescription: 'Select and remove specific pages from your PDF document easily.'
  },
  {
    id: 'reorder-pages',
    name: 'Reorder Pages',
    description: 'Change the order of pages in your PDF.',
    icon: ArrowDownUp,
    category: 'Organize',
    seoTitle: 'Reorder PDF Pages Online - Sort PDF Pages',
    seoDescription: 'Drag and drop to reorder the pages of your PDF document.'
  },

  // Adding more to reach 50...
  { id: 'pdf-to-pdfa', name: 'PDF to PDF/A', description: 'Convert PDF to PDF/A for long-term archiving.', icon: FileArchive, category: 'Convert to PDF', seoTitle: 'Convert PDF to PDF/A Online', seoDescription: 'Ensure your documents are preserved for the future by converting them to PDF/A.' },
  { id: 'repair-pdf', name: 'Repair PDF', description: 'Fix corrupted or damaged PDF files.', icon: FileWarning, category: 'Edit', seoTitle: 'Repair PDF Online - Fix Corrupted PDF', seoDescription: 'Recover data from damaged or corrupted PDF documents.' },
  { id: 'ocr-pdf', name: 'OCR PDF', description: 'Convert scanned PDFs to searchable documents.', icon: Search, category: 'Edit', seoTitle: 'OCR PDF Online - Searchable PDF', seoDescription: 'Use Optical Character Recognition to make scanned PDFs searchable and editable.' },
  { id: 'compare-pdf', name: 'Compare PDF', description: 'Find differences between two PDF versions.', icon: Layers, category: 'Edit', seoTitle: 'Compare PDF Online - Find Differences', seoDescription: 'Compare two PDF files and highlight the differences between them.' },
  { id: 'flatten-pdf', name: 'Flatten PDF', description: 'Merge all layers and form fields into one.', icon: Minimize, category: 'Edit', seoTitle: 'Flatten PDF Online', seoDescription: 'Flatten your PDF to make it non-editable and preserve its appearance.' },
  { id: 'grayscale-pdf', name: 'Grayscale PDF', description: 'Convert colorful PDFs to black and white.', icon: Settings, category: 'Edit', seoTitle: 'Convert PDF to Grayscale Online', seoDescription: 'Save ink by converting your colorful PDF documents to black and white.' },
  { id: 'crop-pdf', name: 'Crop PDF', description: 'Trim the edges of your PDF pages.', icon: Scissors, category: 'Edit', seoTitle: 'Crop PDF Online - Trim PDF Edges', seoDescription: 'Crop your PDF pages to remove white margins or focus on specific content.' },
  { id: 'resize-pdf', name: 'Resize PDF', description: 'Change the page size of your PDF.', icon: Maximize, category: 'Edit', seoTitle: 'Resize PDF Online - Change Page Size', seoDescription: 'Change the dimensions of your PDF pages to A4, Letter, or custom sizes.' },
  { id: 'metadata-editor', name: 'Metadata Editor', description: 'Edit PDF title, author, and keywords.', icon: FileEdit, category: 'Edit', seoTitle: 'Edit PDF Metadata Online', seoDescription: 'Change the internal metadata of your PDF files like Title, Author, and Subject.' },
  { id: 'pdf-to-markdown', name: 'PDF to Markdown', description: 'Convert PDF content to Markdown format.', icon: FileCode, category: 'Convert from PDF', seoTitle: 'Convert PDF to Markdown Online', seoDescription: 'Convert your PDF documents to clean Markdown for documentation and web use.' },
  { id: 'markdown-to-pdf', name: 'Markdown to PDF', description: 'Convert Markdown files to PDF.', icon: FileCode, category: 'Convert to PDF', seoTitle: 'Convert Markdown to PDF Online', seoDescription: 'Create professional PDF documents from your Markdown files.' },
  { id: 'pdf-to-csv', name: 'PDF to CSV', description: 'Extract tables from PDF to CSV format.', icon: Table, category: 'Convert from PDF', seoTitle: 'Convert PDF to CSV Online', seoDescription: 'Extract tabular data from PDF files and save it as a CSV file.' },
  { id: 'csv-to-pdf', name: 'CSV to PDF', description: 'Convert CSV data to PDF tables.', icon: Table, category: 'Convert to PDF', seoTitle: 'Convert CSV to PDF Online', seoDescription: 'Turn your CSV data into clean, readable PDF tables.' },
  { id: 'pdf-to-xml', name: 'PDF to XML', description: 'Convert PDF structure to XML format.', icon: FileCode, category: 'Convert from PDF', seoTitle: 'Convert PDF to XML Online', seoDescription: 'Convert PDF documents to XML for data processing and integration.' },
  { id: 'xml-to-pdf', name: 'XML to PDF', description: 'Convert XML data to PDF documents.', icon: FileCode, category: 'Convert to PDF', seoTitle: 'Convert XML to PDF Online', seoDescription: 'Generate PDF documents from XML data structures.' },
  { id: 'pdf-to-json', name: 'PDF to JSON', description: 'Convert PDF data to JSON format.', icon: FileJson, category: 'Convert from PDF', seoTitle: 'Convert PDF to JSON Online', seoDescription: 'Extract data from PDF files and convert it to JSON format.' },
  { id: 'json-to-pdf', name: 'JSON to PDF', description: 'Convert JSON data to PDF.', icon: FileJson, category: 'Convert to PDF', seoTitle: 'Convert JSON to PDF Online', seoDescription: 'Generate PDF reports from JSON data.' },
  { id: 'pdf-to-rtf', name: 'PDF to RTF', description: 'Convert PDF to Rich Text Format.', icon: FileText, category: 'Convert from PDF', seoTitle: 'Convert PDF to RTF Online', seoDescription: 'Convert your PDF documents to RTF for compatibility with various word processors.' },
  { id: 'rtf-to-pdf', name: 'RTF to PDF', description: 'Convert RTF files to PDF.', icon: FileText, category: 'Convert to PDF', seoTitle: 'Convert RTF to PDF Online', seoDescription: 'Convert Rich Text Format files to high-quality PDF documents.' },
  { id: 'pdf-to-epub', name: 'PDF to EPUB', description: 'Convert PDF to eBook format.', icon: BookOpen, category: 'Convert from PDF', seoTitle: 'Convert PDF to EPUB Online', seoDescription: 'Convert your PDF documents to EPUB format for comfortable reading on eBooks.' },
  { id: 'epub-to-pdf', name: 'EPUB to PDF', description: 'Convert EPUB eBooks to PDF.', icon: BookOpen, category: 'Convert to PDF', seoTitle: 'Convert EPUB to PDF Online', seoDescription: 'Convert EPUB eBooks to PDF for viewing on any device.' },
  { id: 'extract-images', name: 'Extract Images', description: 'Save all images from a PDF separately.', icon: ImageIcon, category: 'Convert from PDF', seoTitle: 'Extract Images from PDF Online', seoDescription: 'Extract all embedded images from your PDF document and save them as separate files.' },
  { id: 'extract-text', name: 'Extract Text', description: 'Get all text content from your PDF.', icon: Type, category: 'Convert from PDF', seoTitle: 'Extract Text from PDF Online', seoDescription: 'Quickly extract all text from your PDF files for reuse.' },
  { id: 'fill-sign', name: 'Fill & Sign', description: 'Fill out PDF forms and sign them.', icon: FileCheck, category: 'Edit', seoTitle: 'Fill and Sign PDF Online', seoDescription: 'Fill out PDF forms and add your signature easily.' },
  { id: 'pdf-viewer', name: 'PDF Viewer', description: 'View your PDF files online.', icon: Eye, category: 'Popular', seoTitle: 'Free Online PDF Viewer', seoDescription: 'View your PDF documents in your browser without installing any software.' },
  { id: 'pdf-to-html', name: 'PDF to HTML', description: 'Convert PDF to web-ready HTML.', icon: Globe, category: 'Convert from PDF', seoTitle: 'Convert PDF to HTML Online', seoDescription: 'Convert your PDF documents into clean, responsive HTML code.' },
  { id: 'remove-restrictions', name: 'Remove Restrictions', description: 'Remove printing and copying limits.', icon: Unlock, category: 'Security', seoTitle: 'Remove PDF Restrictions Online', seoDescription: 'Remove restrictions on printing, copying, and editing from your PDF documents.' }
];
