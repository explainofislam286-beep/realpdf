import React, { useState, useCallback, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Upload, 
  File, 
  X, 
  Download, 
  CheckCircle2, 
  Loader2,
  AlertCircle,
  Info
} from 'lucide-react';
import { PDFTool } from '../constants/tools';
import { cn } from '../lib/utils';
import { PDFProcessor } from '../services/pdfProcessor';
import { getToolIcon } from '../lib/icons';

export const ToolDetail = () => {
  const { toolId } = useParams<{ toolId: string }>();
  const [tool, setTool] = useState<PDFTool | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processedData, setProcessedData] = useState<Uint8Array | null>(null);

  useEffect(() => {
    if (toolId) {
      fetch(`/api/tools/${toolId}`)
        .then(res => res.json())
        .then(data => {
          setTool(data);
          setIsLoading(false);
        })
        .catch(err => {
          console.error('Failed to fetch tool', err);
          setIsLoading(false);
        });
    }
  }, [toolId]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(prev => [...prev, ...acceptedFiles]);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: toolId?.includes('pdf') ? { 'application/pdf': ['.pdf'] } : undefined,
    multiple: toolId === 'merge-pdf' || toolId === 'jpg-to-pdf'
  } as any);

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      let result: Uint8Array | null = null;

      if (toolId === 'merge-pdf') {
        result = await PDFProcessor.mergePDFs(files);
      } else if (toolId === 'rotate-pdf') {
        result = await PDFProcessor.rotatePDF(files[0], 90);
      } else {
        // For other tools, simulate processing
        await new Promise(resolve => setTimeout(resolve, 2000));
      }

      setProcessedData(result);
      setIsComplete(true);
    } catch (err) {
      console.error(err);
      setError('An error occurred while processing your file. Please ensure it is a valid PDF and try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (processedData) {
      PDFProcessor.download(processedData, `processed-${toolId}.pdf`);
    } else {
      // Mock download for simulated tools
      alert('Download started (Simulated)');
    }
  };

  const reset = () => {
    setFiles([]);
    setIsComplete(false);
    setError(null);
    setProcessedData(null);
  };

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!tool) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center px-4">
        <h1 className="text-2xl font-bold text-slate-900">Tool not found</h1>
        <Link to="/" className="mt-4 text-indigo-600 hover:underline">Back to home</Link>
      </div>
    );
  }

  const Icon = getToolIcon(tool.id);

  return (
    <main className="min-h-screen bg-slate-50 py-12">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors mb-8"
        >
          <ArrowLeft size={16} />
          Back to all tools
        </Link>

        <div className="mb-12 text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-white text-indigo-600 shadow-xl shadow-indigo-500/10">
            <Icon size={40} />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            {tool.name}
          </h1>
          <p className="mt-4 text-lg text-slate-600">
            {tool.description}
          </p>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
          <AnimatePresence mode="wait">
            {!isComplete ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                {files.length === 0 ? (
                  <div 
                    {...getRootProps()} 
                    className={cn(
                      "group relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 py-20 transition-all cursor-pointer",
                      isDragActive ? "border-indigo-500 bg-indigo-50/50" : "hover:border-indigo-400 hover:bg-slate-50"
                    )}
                  >
                    <input {...getInputProps()} />
                    <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-indigo-50 text-indigo-600 group-hover:scale-110 transition-transform">
                      <Upload size={32} />
                    </div>
                    <p className="text-lg font-semibold text-slate-900">
                      {isDragActive ? "Drop files here" : "Choose files or drag & drop"}
                    </p>
                    <p className="mt-2 text-sm text-slate-500">
                      PDF, Word, Excel, PPT, JPG, PNG
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                      {files.map((file, index) => (
                        <div key={index} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 p-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-indigo-600 shadow-sm">
                              <File size={20} />
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-slate-900 truncate max-w-[200px] sm:max-w-md">
                                {file.name}
                              </p>
                              <p className="text-xs text-slate-500">
                                {(file.size / 1024 / 1024).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                          <button 
                            onClick={() => removeFile(index)}
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                          >
                            <X size={20} />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center gap-4">
                      <button 
                        onClick={handleProcess}
                        disabled={isProcessing}
                        className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-4 text-sm font-bold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 disabled:opacity-50 transition-all"
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="animate-spin" size={20} />
                            Processing...
                          </>
                        ) : (
                          `Process ${tool.name}`
                        )}
                      </button>
                      <button 
                        onClick={reset}
                        disabled={isProcessing}
                        className="rounded-xl border border-slate-200 bg-white px-6 py-4 text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 transition-all"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="complete"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center py-10 text-center"
              >
                <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-500">
                  <CheckCircle2 size={48} />
                </div>
                <h2 className="text-2xl font-bold text-slate-900">Task Completed!</h2>
                <p className="mt-2 text-slate-500">Your file is ready for download.</p>
                
                <div className="mt-10 flex flex-col sm:flex-row gap-4 w-full">
                  <button 
                    onClick={handleDownload}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-indigo-600 py-4 text-sm font-bold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 transition-all"
                  >
                    <Download size={20} />
                    Download File
                  </button>
                  <button 
                    onClick={reset}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-4 text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all"
                  >
                    Start Over
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {error && (
            <div className="mt-6 flex items-center gap-2 rounded-xl bg-red-50 p-4 text-sm text-red-600">
              <AlertCircle size={18} />
              {error}
            </div>
          )}
        </div>

        {/* SEO Optimized Content for the Tool */}
        <div className="mt-16 space-y-12">
          <section className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-bold text-slate-900">{tool.seoTitle}</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              {tool.seoDescription}
            </p>
            
            {tool.longDescription && (
              <div className="mt-8 rounded-2xl bg-white p-8 shadow-sm border border-slate-100">
                <div className="flex items-center gap-2 mb-4 text-indigo-600">
                  <Info size={20} />
                  <h3 className="text-xl font-bold text-slate-900 m-0">Deep Information</h3>
                </div>
                <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">
                  {tool.longDescription}
                </p>
              </div>
            )}

            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">How to use {tool.name}</h3>
                <ol className="space-y-4 text-slate-600">
                  <li className="flex gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-600">1</span>
                    <span>Upload your files to our {tool.name} tool.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-600">2</span>
                    <span>Wait for the processing to complete in seconds.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-600">3</span>
                    <span>Download your processed file instantly.</span>
                  </li>
                </ol>
              </div>
              <div className="bg-indigo-50 p-8 rounded-2xl">
                <h3 className="text-xl font-bold text-indigo-900 mb-4">Pro Tip</h3>
                <p className="text-indigo-700 text-sm leading-relaxed">
                  Did you know you can use PDFMaster on any device? Our tools are fully responsive and work perfectly on smartphones and tablets, so you can process your documents on the go!
                </p>
              </div>
            </div>
          </section>

          <section className="border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-8">Frequently Asked Questions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { q: `Is ${tool.name} free to use?`, a: "Yes, all our tools are 100% free with no hidden costs or subscriptions." },
                { q: "Are my files secure?", a: "Absolutely. We use SSL encryption and process files locally in your browser whenever possible." },
                { q: "Do I need to install anything?", a: "No, PDFMaster is a web-based platform that works in any modern browser." },
                { q: "Is there a file size limit?", a: "We support files up to 100MB for most tools to ensure fast processing." }
              ].map((faq, i) => (
                <div key={i} className="space-y-2">
                  <h4 className="font-bold text-slate-900">{faq.q}</h4>
                  <p className="text-sm text-slate-600">{faq.a}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </main>
  );
};
