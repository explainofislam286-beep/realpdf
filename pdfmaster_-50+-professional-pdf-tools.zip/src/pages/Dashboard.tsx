import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Search, 
  Edit2, 
  Save, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  LogOut,
  ChevronRight,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PDFTool } from '../constants/tools';
import { cn } from '../lib/utils';

export const Dashboard = () => {
  const [tools, setTools] = useState<PDFTool[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingTool, setEditingTool] = useState<PDFTool | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      navigate('/admin-login');
      return;
    }
    fetchTools();
  }, [navigate]);

  const fetchTools = async () => {
    try {
      const response = await fetch('/api/tools');
      const data = await response.json();
      setTools(data);
    } catch (err) {
      console.error('Failed to fetch tools', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    navigate('/admin-login');
  };

  const handleEdit = (tool: PDFTool) => {
    setEditingTool({ ...tool });
    setMessage(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTool) return;

    setIsSaving(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/tools/${editingTool.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingTool),
      });

      if (response.ok) {
        setMessage({ type: 'success', text: 'Tool updated successfully!' });
        setTools(tools.map(t => t.id === editingTool.id ? editingTool : t));
        setTimeout(() => setEditingTool(null), 1500);
      } else {
        setMessage({ type: 'error', text: 'Failed to update tool.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'An error occurred while saving.' });
    } finally {
      setIsSaving(false);
    }
  };

  const filteredTools = tools.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-200">
              <LayoutDashboard size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Admin Dashboard</h1>
              <p className="text-sm text-slate-500">Manage tool metadata and content</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all"
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tool List */}
          <div className="lg:col-span-1 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search tools..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-4 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
              />
            </div>
            <div className="max-h-[70vh] overflow-y-auto rounded-2xl border border-slate-200 bg-white shadow-sm custom-scrollbar">
              {filteredTools.map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => handleEdit(tool)}
                  className={cn(
                    "flex w-full items-center justify-between border-b border-slate-100 p-4 text-left transition-all hover:bg-slate-50",
                    editingTool?.id === tool.id ? "bg-indigo-50 border-l-4 border-l-indigo-600" : ""
                  )}
                >
                  <div>
                    <p className="text-sm font-bold text-slate-900">{tool.name}</p>
                    <p className="text-xs text-slate-500">{tool.category}</p>
                  </div>
                  <ChevronRight size={16} className="text-slate-400" />
                </button>
              ))}
            </div>
          </div>

          {/* Edit Form */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {editingTool ? (
                <motion.div
                  key={editingTool.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200/50 border border-slate-100"
                >
                  <div className="mb-8 flex items-center justify-between">
                    <h2 className="text-xl font-bold text-slate-900">Edit {editingTool.name}</h2>
                    <button onClick={() => setEditingTool(null)} className="p-2 text-slate-400 hover:text-slate-600">
                      <X size={20} />
                    </button>
                  </div>

                  <form onSubmit={handleSave} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Tool Name</label>
                        <input 
                          type="text" 
                          value={editingTool.name}
                          onChange={(e) => setEditingTool({ ...editingTool, name: e.target.value })}
                          className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Category</label>
                        <select 
                          value={editingTool.category}
                          onChange={(e) => setEditingTool({ ...editingTool, category: e.target.value as any })}
                          className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm focus:border-indigo-500 focus:outline-none"
                        >
                          <option value="Popular">Popular</option>
                          <option value="Convert to PDF">Convert to PDF</option>
                          <option value="Convert from PDF">Convert from PDF</option>
                          <option value="Edit">Edit</option>
                          <option value="Security">Security</option>
                          <option value="Organize">Organize</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Short Description</label>
                      <textarea 
                        value={editingTool.description}
                        onChange={(e) => setEditingTool({ ...editingTool, description: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm focus:border-indigo-500 focus:outline-none"
                        rows={2}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-500">SEO Title</label>
                        <input 
                          type="text" 
                          value={editingTool.seoTitle}
                          onChange={(e) => setEditingTool({ ...editingTool, seoTitle: e.target.value })}
                          className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-500">SEO Description</label>
                        <input 
                          type="text" 
                          value={editingTool.seoDescription}
                          onChange={(e) => setEditingTool({ ...editingTool, seoDescription: e.target.value })}
                          className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm focus:border-indigo-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Long Description (Deep Information)</label>
                      <textarea 
                        value={editingTool.longDescription}
                        onChange={(e) => setEditingTool({ ...editingTool, longDescription: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm focus:border-indigo-500 focus:outline-none"
                        rows={6}
                        placeholder="Detailed information about the tool, its benefits, and technical details..."
                      />
                    </div>

                    <div className="flex items-center gap-4 pt-4">
                      <button 
                        type="submit"
                        disabled={isSaving}
                        className="flex items-center gap-2 rounded-xl bg-indigo-600 px-8 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 transition-all disabled:opacity-50"
                      >
                        {isSaving ? 'Saving...' : (
                          <>
                            <Save size={18} />
                            Save Changes
                          </>
                        )}
                      </button>
                      {message && (
                        <div className={cn(
                          "flex items-center gap-2 text-sm font-semibold",
                          message.type === 'success' ? "text-emerald-600" : "text-red-600"
                        )}>
                          {message.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
                          {message.text}
                        </div>
                      )}
                    </div>
                  </form>
                </motion.div>
              ) : (
                <div className="flex h-full flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-200 bg-white p-12 text-center">
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-50 text-slate-400">
                    <Edit2 size={32} />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">Select a tool to edit</h3>
                  <p className="mt-2 text-sm text-slate-500">Click on any tool from the list to start editing its content and SEO metadata.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};
