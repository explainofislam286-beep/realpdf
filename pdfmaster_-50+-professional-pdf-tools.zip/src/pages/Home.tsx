import React from 'react';
import { motion } from 'motion/react';
import { FileText, Zap, ShieldCheck, Globe } from 'lucide-react';
import { ToolGrid } from '../components/ToolGrid';

export const Home = () => {
  return (
    <main className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 py-24 sm:py-32">
        <div className="absolute inset-0 z-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(79,70,229,0.4),transparent_50%)]"></div>
          <div className="absolute top-0 left-0 h-full w-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        </div>
        
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl lg:text-7xl">
              Every PDF tool you'll <span className="text-indigo-400">ever need</span>.
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-300">
              50+ professional-grade PDF tools to merge, split, compress, convert, and edit your documents in seconds. Fast, secure, and 100% free.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <a 
                href="#popular" 
                className="rounded-full bg-indigo-600 px-8 py-4 text-sm font-semibold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-all"
              >
                Get Started Free
              </a>
              <a href="#all-tools" className="text-sm font-semibold leading-6 text-white hover:text-indigo-400 transition-colors">
                View All Tools <span aria-hidden="true">→</span>
              </a>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="mt-16 grid grid-cols-2 gap-4 sm:grid-cols-4"
          >
            {[
              { icon: Zap, label: 'Lightning Fast' },
              { icon: ShieldCheck, label: 'Secure & Private' },
              { icon: Globe, label: '100% Online' },
              { icon: FileText, label: 'High Quality' },
            ].map((feature, i) => (
              <div key={i} className="flex flex-col items-center gap-2 rounded-2xl bg-white/5 p-4 backdrop-blur-sm">
                <feature.icon className="h-6 w-6 text-indigo-400" />
                <span className="text-xs font-medium text-slate-300 uppercase tracking-widest">{feature.label}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <div id="all-tools" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <ToolGrid />
      </div>

      {/* SEO Content Section */}
      <section className="bg-slate-50 py-24">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl mb-8">
            The World's Most Comprehensive PDF Suite
          </h2>
          <div className="space-y-6 text-lg text-slate-600 leading-relaxed text-left">
            <p>
              PDFMaster is designed to be your one-stop solution for all document processing needs. Whether you're a student looking to merge lecture notes, a professional needing to sign contracts, or a developer converting data formats, our 50+ tools have you covered.
            </p>
            <p>
              Our platform uses advanced client-side processing, meaning your files are processed directly in your browser whenever possible. This ensures maximum privacy and security as your sensitive data never leaves your device.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
                <h3 className="text-xl font-bold text-slate-900 mb-4">Why Choose PDFMaster?</h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex gap-2">✅ <strong>No Installation:</strong> Works directly in any modern browser.</li>
                  <li className="flex gap-2">✅ <strong>Privacy First:</strong> Files are processed locally when possible.</li>
                  <li className="flex gap-2">✅ <strong>Free Forever:</strong> No hidden costs or subscriptions.</li>
                  <li className="flex gap-2">✅ <strong>Multi-Platform:</strong> Works on Windows, Mac, Linux, and mobile.</li>
                </ul>
              </div>
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
                <h3 className="text-xl font-bold text-slate-900 mb-4">Professional Features</h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex gap-2">🚀 <strong>High Compression:</strong> Reduce file size by up to 90%.</li>
                  <li className="flex gap-2">🎨 <strong>Quality Preservation:</strong> Keep fonts and layouts intact.</li>
                  <li className="flex gap-2">🔒 <strong>AES-256 Encryption:</strong> Secure your PDFs with military-grade tech.</li>
                  <li className="flex gap-2">🔄 <strong>Batch Processing:</strong> Handle multiple files at once.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};
